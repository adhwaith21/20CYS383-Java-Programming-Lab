package com.amrita.jpl.cys21063.endsem;

import com.amrita.jpl.cys21063.endsem.File;

public interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void displayAllFiles();
}


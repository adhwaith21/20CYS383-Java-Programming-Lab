package com.amrita.jpl.cys21063.endsem;


public interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void displayAllFiles();
}

